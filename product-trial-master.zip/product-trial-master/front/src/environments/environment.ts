export const environment = {
  production: true,
  apiUrl: "https://api.clement-tell-product-trial.com/products"
};
